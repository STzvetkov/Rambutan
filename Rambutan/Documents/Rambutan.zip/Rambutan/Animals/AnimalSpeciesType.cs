﻿namespace Zoo.Animals
{
    public enum AnimalSpeciesType
    {
        ClownFish,
        Dolphin,
        Eagle,
        Hoodie,
        Ostrich,
        Penguin,
        Bear,
        Deer,
        Fox,
        Lion,
        Monkey,
        Python,
        Rabbit
    }
}

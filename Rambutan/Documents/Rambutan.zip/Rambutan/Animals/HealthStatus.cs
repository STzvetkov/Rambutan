﻿namespace Zoo.Animals
{
    public enum HealthStatus
    {
        Healthy,
        Sick
    }
}

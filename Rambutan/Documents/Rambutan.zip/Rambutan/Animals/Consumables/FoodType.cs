﻿namespace Zoo.Animals.Consumables
{
    public enum FoodType
    {
        Meat,
        Plant,
        Mix
    }
}

﻿namespace Zoo.Interfaces
{
    public interface IFeedable
    {
        void Eat(int quantity);
    }
}

﻿namespace Zoo.Interfaces
{
    interface ICage
    {
        double Width { get; }
        double Height { get; }
        double Depth { get; }
    }
}

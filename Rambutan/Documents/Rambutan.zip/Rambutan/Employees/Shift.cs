﻿namespace Zoo.Employees
{
    public enum Shift
    {
        Day,
        Night
    }
}

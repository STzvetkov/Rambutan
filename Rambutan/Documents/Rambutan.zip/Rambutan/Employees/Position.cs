﻿namespace Zoo.Employees
{
    public enum Position
    {
        Director,
        Veterinarian,
        Nutritionist,
        ZooKeeper
    }
}
